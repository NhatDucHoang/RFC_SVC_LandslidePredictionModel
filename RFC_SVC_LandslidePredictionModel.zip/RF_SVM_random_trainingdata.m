function kq = RF_with_DUC_data()
% Read_data1 = xlsread('D:/machine learning/AHung/LandslidelangSon.xlsx');
% save Read_data1 Read_data1;
load Read_data1 Read_data1;
zero_pos = find(Read_data1(:,end) ==0);
Read_data1(zero_pos,end) = Read_data1(zero_pos,end)+2;
close all;
global s;     
s = struct ( 'idx',0,'child',[0 0 0 0 0 0 0 0 0 0],'height',0, ...
             'range_matrix', 0, 'mean_range', {0}, 'rand_cut', [0 0], ...
             'remain_data', {0},'label',0);

training_data1 = Read_data1;
class_num = 2;
% % % % % --------------- training a forest -----------------------
tree_num = 10;
max_allow_height = 4;
cut_num = 1;
tic
% % for j = 1:tree_num
% % %     j=j;
% %     b1{j} = training_a_tree_nearest(training_data1,max_allow_height,cut_num);
% % end
t1=toc*10^3;
% save b1 b1 
load b1 b1
dem = 0;
dem_0=0;
countTP=0;
countTN=0;
countFP=0;
countFN=0;
% -----------------------------------
%Test test_data
tic
for k = 1:size(Read_data1,1)
    test_point = Read_data1(k,1:end-1);
    T_LAbEL = [];
     for j=1:tree_num
        T_LAbEL =[T_LAbEL test_sample(test_point, b1{j})];
    end
      max_num = 0;
    while ~isempty(T_LAbEL)
        if length(find(T_LAbEL==T_LAbEL(1)))>=max_num
            tt = T_LAbEL(1);
            max_num = length(find(T_LAbEL==T_LAbEL(1)));
        end
        T_LAbEL = T_LAbEL(find(T_LAbEL~=T_LAbEL(1)));
    end 
    if tt == Read_data1(k,end)
%        k=k;
        dem = dem+1;
           elseif tt==0
        dem_0=dem_0+1;
    end
    if (and(tt == Read_data1(k,end),Read_data1(k,end)==1))
       countTP=countTP+1;
     elseif (and(tt == Read_data1(k,end),Read_data1(k,end)~=1))  
        countTN=countTN+1; 
    elseif (and(tt ~= Read_data1(k,end),Read_data1(k,end)==1))
        countFP=countFP+1;
    elseif (and(tt ~= Read_data1(k,end),Read_data1(k,end)~=1))   
        countFN=countFN+1;
    end
end
t2=toc*10^3;
% b1 = b1;dem = dem;
TP=countTP;
% dem_0 = dem_0;
FN=countFN;
TN=countTN;
FP=countFP;
disp( [' TP  FN TN  FP = ' ]);
disp([TP  FN TN  FP])
elast_time = [t1 t2];
%Classification Accuracy Rate
% CAR=(TP+TN)/length(rand_left_for_train)
% precision=TP/(TP+FP)
% recall=TP/(TP+FN)
% misclassification=(countFN+countFP)/length(rand_left_for_train)
% TPR = TP/(TP + FN)
% FNR = FN/(TP + FN)
% FPR = FP/(FP + TN)
% TNR = TN/(FP + TN)
% F1_score=2*(precision*recall/( precision+recall))
% % x=[FPR];
% % y=[TPR];
% % AUC=trapz(x,y)
% result1 = dem/length(rand_left_for_train)*100;
% save result1 result1;
% ==================================================================
function a = training_a_tree_nearest(training_data1,max_allow_height,cut_num)
global s;
% training_data1 = training_data1'; 
A = [min(training_data1(:,1:end-1)); max(training_data1(:,1:end-1))];

a = s;
a.height = 1;
a.remain_data = training_data1;
a.mean_range = mean(A,1);
a.range_matrix = A;
cur_i = 1;
a.svm= [];

while cur_i<=length(a)
    t = a(cur_i);
    if ~isempty(t.remain_data)
        if max(t.remain_data(:,end))== min(t.remain_data(:,end))
            a(cur_i).label = min(t.remain_data(:,end));
        elseif t.height<= max_allow_height-1 
            dim_id = mod(t.height-1,10)+1 ; %fix later
%            
            range = t.range_matrix(:,dim_id);
            range_lim = [min(t.remain_data(:,dim_id)) max(t.remain_data(:,dim_id))];
            if range_lim(2)== range_lim(1)
                a(cur_i).rand_cut = range_lim(1);
                a = add_node(a,cur_i,1,t.range_matrix,t.mean_range,t.remain_data,t.height+1,{0});
%                 a = add_node(a,cur_i,2,[],[],[],t.height+1,dim_id,{0});
              
                a(a(cur_i).child(2)).label = get_nearest_label(training_data,t.mean_range);
                hhhhh = a(cur_i).height;
            else
                t_val1 = sort(rand(1,cut_num)*(range_lim(2)-range_lim(1))+range_lim(1));
                t_val2 = [t_val1 Inf];
                t_val = sort([range' t_val1]);
                a(cur_i).rand_cut = t_val1;
                for j = 1:length(t_val2)
                    re_pos = find(t.remain_data(:,dim_id)<t_val2(j));
                    re_data = t.remain_data(re_pos,:);
                    store_pos = find(t.remain_data(:,dim_id)>=t_val2(j));
                    t.remain_data = t.remain_data(store_pos,:);
                    mean_rg_matrix = t.mean_range;
                    mean_rg_matrix(dim_id) = mean([t_val(j) t_val(j+1)]);
                    next_dim_range = t.range_matrix;
                    next_dim_range(:,dim_id) = [t_val(j) t_val(j+1)]';
                    svmtt = [];
                    a = add_node(a,cur_i,j,next_dim_range,mean_rg_matrix,re_data,t.height+1,svmtt);
%                     a = add_node(a,cur_i,jj,next_dim_range,mean_rg_matrix,re_data,dim_id); % add_node(tree,cur_i,child,limit,remain_data,height)
                end
                      uuuuuu = 1; 

            end
        else
%                         remain_label = t.remain_data(:,end);
%                         remain_label = sort(remain_label);
%                         max_temp=0;
%                         while ~isempty(remain_label)
%                             if length(find(remain_label==remain_label(1)))>max_temp
%                                 max_temp = length(find(remain_label==remain_label(1)));
%                                 a(cur_i).label = remain_label(1);
%                             end
%                             remain_label = remain_label(find(remain_label~=remain_label(1)));
%                         end
  %Insert SVM core
                        hhhhh = a(cur_i).height;
                        XX = a(cur_i).remain_data(:,1:14);
                        YY = a(cur_i).remain_data(:,15);
                        svmtt = fitcsvm(XX,YY,'Standardize',true,'KernelFunction','RBF',...
                                'KernelScale','auto');
                        a(cur_i).svm = svmtt;
                        
        end
    else
%         temp = get_nearest_label(training_data,a(cur_i).mean_range);
%         a(cur_i).label = temp;
    end
    a(cur_i).remain_data = [];
    a(cur_i).mean_range = [];
    a(cur_i).range_matrix = [];
    cur_i = cur_i + 1;
end
% ==================================================================
function label = get_nearest_label(training_data,mid_point)    

clone_line = (mid_point'*ones(1,size(training_data,1)))';
diff_square = (clone_line - training_data(:,1:end-1)).^2;
dis_dif = sum(diff_square,2);
min_dis = find(dis_dif==min(dis_dif));
label = training_data(min_dis(1),end);
% ==================================================================
function test_label = test_sample(test_point, a) 

test_label = 0;
ii =1;
while ii<=length(a) && ii~=0
    if a(ii).label ~=0
        test_label = a(ii).label;
        return
    else
        if length(a(ii).svm) == 1
            test_label=predict(a(ii).svm,test_point);
            return
        else
            cut_list = [a(ii).rand_cut Inf];
            for j=1:length(cut_list)
                dim_id = mod(a(ii).height-1,12)+1;
%                 dim_id=a(ii).dim_id;
                if test_point(dim_id) <= cut_list(j)
    % %                 if j>length(a(ii).child)
    % %                     test_point
    % %                     dim_id
    % %                     temp = a(ii)
    % %                     temp_RD = temp.remain_data
    % %                 end
                    ii = a(ii).child(j);
                    break;
                end
            end
        end
    end
end
% ==================================================================
function aa = add_node(a , cur_i, child_id , next_dim_range, mean_rg_matrix, remain_data,height,svm)
global s;
temp = s;
temp.idx = length(a) + 1;
a(cur_i).child(child_id) = length(a) + 1;
temp.height = height;
% temp.dim_id = dim_id;
temp.remain_data = remain_data;
temp.range_matrix = next_dim_range;
temp.mean_range = mean_rg_matrix;
temp.svm = svm;
aa = [a temp];


